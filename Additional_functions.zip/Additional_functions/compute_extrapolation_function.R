
#####################################

# This function is from the package dsmextra (Bouchet et al. 2020). The only variation is that it initially calls additional functions from the dsmextra package that we have slightly modified.

######################################

compute_extrapolation_func <- function(samples,
                                  segments,
                                  covariate.names,
                                  prediction.grid,
                                  coordinate.system,
                                  resolution = NULL,
                                  verbose = TRUE){
  
  
  # Load functions with edits
  
  source(here("Additional_functions/ExDet_function.R"))
  
  source(here("Additional_functions/summarise_extrapolation_function.R"))
  
  source(here("Additional_functions/additional_functions.R"))
  
  
  check_crs <- function(...){
    # Extract dots
    dots  <- list(...)
    names(dots) <- as.character(match.call()[-1L])
    # Extract CRS (if necessary)
    dots  <- lapply(dots, function(dot){
      if(!is.null(dot)){
        if(inherits(dot, "CRS")) return(dot)
        else return(raster::crs(dot))
      }
    })
    dots <- compact(dots)
    if(length(dots) > 1L){
      # Extract CRS for the first element (the 'baseline')
      crs_base <- dots[[1]]
      # Compare baseline CRS to each remaining CRS
      lapply(2:length(dots), function(i){
        crs_arg   <- dots[[i]]
        crs_check   <- all.equal(crs_base, crs_arg)
        if(!isTRUE(crs_check)){
          warning("The CRSs of '", names(dots)[1], "' and '", names(dots)[i], "' are not identical.",
                  immediate. = TRUE, call. = FALSE)
          message("  -- details: ", crs_check, ".")
          message("  -- ",  names(dots)[1], " CRS: '", crs_base, "'.")
          message("  -- ",  names(dots)[2], " CRS: '", crs_arg, "'.\n")
        }
      })
    }
    return(invisible())
  }
  
  #---------------------------------------------
  # Perform function checks
  #---------------------------------------------
  
  calls <- names(sapply(match.call(), deparse))[-1]
  
  if(any("segments" %in% calls)) {
    if(verbose) warning("The 'segments' argument is deprecated, please use 'samples' instead.")
    samples <- segments
  }
  
  if(!"data.frame"%in%class(prediction.grid)) stop("pred.grid must be of class data.frame")
  if(!"data.frame"%in%class(samples)) stop("samples must be of class data.frame")
  
  if(!"x"%in%names(prediction.grid) | !"y"%in%names(prediction.grid)) stop("pred.grid must contain x and y coordinates")
  
  if(!all(covariate.names%in%names(samples))) stop("Missing/unrecognised covariates in the sample data")
  if(!all(covariate.names%in%names(prediction.grid))) stop("Missing/unrecognised covariates in the prediction grid")
  
  coordinate.system <- check_crs(coordinate.system = coordinate.system)
  
  samples <- na.omit(samples) # Cannot have NA values
  prediction.grid <- na.omit(prediction.grid)
  
  #---------------------------------------------
  # Check if prediction grid is regular
  #---------------------------------------------
  
  check.grid <- prediction.grid %>%
    dplyr::select(x, y) %>%
    dplyr::mutate(z = 1)
  
  grid.regular <- try(raster::rasterFromXYZ(check.grid), silent = TRUE)
  
  # grid.regular <- try(raster::rasterFromXYZ(check.grid,
  #                     res = ifelse(is.null(resolution), c(NA,NA), resolution)),
  #                     silent = TRUE)
  
  #---------------------------------------------
  # If grid is irregular, rasterise prediction.grid based on specified resolution
  #---------------------------------------------
  
  if (class(grid.regular) == "try-error") {
    if (is.null(resolution)) stop("Prediction grid cells are not regularly spaced.\nA target raster resolution must be specified. See package documentation for details.")
    
    if (verbose) warning("Prediction grid cells are not regularly spaced.\nData will be rasterised and covariate values averaged. See package documentation for details.")
    
    RasteriseGrid <- TRUE
  } else if (class(grid.regular) == "RasterLayer" & !is.null(resolution)) {
    if (verbose) warning("New resolution specified.\nData will be rasterised and covariate values averaged. See package documentation for details.")
    
    RasteriseGrid <- TRUE
    
  } else {
    RasteriseGrid <- FALSE
  }
  
  if(RasteriseGrid){
    
    check.grid$z <- NULL
    sp::coordinates(check.grid) <- ~x+y
    sp::proj4string(check.grid) <- coordinate.system
    
    # Create empty raster with desired resolution
    
    ras <- raster::raster(raster::extent(check.grid), res = resolution)
    raster::crs(ras) <- coordinate.system
    
    # Create individual rasters for each covariate
    
    ras.list <- purrr::map(.x = covariate.names,
                           .f = ~raster::rasterize(as.data.frame(check.grid), ras,
                                                   prediction.grid[,.x], fun = mean_ras)) %>%
      purrr::set_names(., covariate.names)
    
    # Combine all rasters
    
    ras.list <- raster::stack(ras.list)
    
    # Update prediction grid
    
    prediction.grid <- raster::as.data.frame(ras.list, xy = TRUE, na.rm = TRUE)
    
    
  } # End if
  
  if(verbose) message("Computing ...")
  
  #---------------------------------------------
  # Define reference and target systems
  #---------------------------------------------
  
  reference <- samples[, covariate.names]
  target <- prediction.grid[, covariate.names]
  
  #---------------------------------------------
  # Run the exdet tool from Mesgaran et al. (2014)
  #---------------------------------------------
  
  mesgaran <- ExDet_func(ref = reference,
                    tg = target,
                    xp = covariate.names)
  
  #---------------------------------------------
  # Add coordinates
  #---------------------------------------------
  
  mesgaran <- prediction.grid %>%
    dplyr::select(x,y) %>%
    cbind(., mesgaran)
  
  #---------------------------------------------
  # Return a list with univariate, combinatorial, and analog conditions as separate elements
  #---------------------------------------------
  
  reslist <- list(data=NULL, rasters=NULL)
  
  reslist$data$all <- mesgaran
  
  reslist$data$univariate <- mesgaran %>%
    dplyr::filter(., ExDet < 0)
  
  reslist$data$combinatorial <- mesgaran %>%
    dplyr::filter(., ExDet > 1)
  
  reslist$data$analogue <- mesgaran %>%
    dplyr::filter(., ExDet >= 0 & ExDet <= 1)
  
  #---------------------------------------------
  # Create rasters from extrapolation/MIC values
  #---------------------------------------------


  reslist$rasters$ExDet <- reslist$data %>%
    purrr::map(., ~ dplyr::select(., x, y, ExDet) %>%
                 safe_raster(.)) %>%
    purrr::map(., "result")

  reslist$rasters$mic <- reslist$data %>%
    purrr::map(., ~ dplyr::select(., x, y, mic) %>%
                 safe_raster(.)) %>%
    purrr::map(., "result")
  
  #---------------------------------------------
  # Check that rasters have been produced for each extrapolation type
  #---------------------------------------------

  null.check <- purrr::map_lgl(.x = reslist$rasters$ExDet, .f = ~is.null(.x))

  ms <- names(null.check[null.check])
  ms <- purrr::map_dbl(.x = reslist$data[ms], .f = ~nrow(.x))
  # ms <- names(ms[ms>0])

  if(length(ms)>0){

    for(i in 1:length(ms)){

      if(ms[i]>0){

        # Extract data

        ds <- reslist$data[names(ms[i])]

        # Build raster

        predr <- prediction.grid %>%
          dplyr::select(x,y) %>%
          dplyr::mutate("ID" = 1) %>%
          raster::rasterFromXYZ(xyz = ., crs = coordinate.system)

        rs <- ps <- purrr::map(.x = ds,
                               .f= ~raster::rasterize(x = .x[,c("x", "y")], y = predr))

        # Reassign values

        for(i in 1:length(rs)){
          rs[[i]][!is.na(rs[[i]])] <- ds[[i]]$ExDet
          ps[[i]][!is.na(ps[[i]])] <- ds[[i]]$mic
        }

        reslist$rasters$ExDet <- append(reslist$rasters$ExDet, rs) %>%
          purrr::discard(is.null)

        reslist$rasters$mic <- append(reslist$rasters$mic, ps) %>%
          purrr::discard(is.null)


      } # End if ms[i] > 0

    } # End for loop length(ms)
  } # End if(length(ms)>0)
  
  #---------------------------------------------
  # Project rasters
  #---------------------------------------------
  # 
  # for(r in 1:length(reslist$rasters$ExDet)){
  #   if(!is.null(reslist$rasters$ExDet[[r]]))raster::projection(reslist$rasters$ExDet[[r]]) <- coordinate.system}
  # 
  # for(r in 1:length(reslist$rasters$mic)){
  #   if(!is.null(reslist$rasters$mic[[r]]))raster::projection(reslist$rasters$mic[[r]]) <- coordinate.system}
  # 
  #  #---------------------------------------------
  #  # Print/save summary
  #  #---------------------------------------------
  
  
  
  sumres <- summarise_extrapolation(extrapolation.object = reslist,
                                    covariate.names = covariate.names,
                                    extrapolation = TRUE,
                                    mic = TRUE)
  
  class(sumres) <- c("extrapolation_results_summary", class(sumres))
  reslist <- append(x = reslist, values = list(summary = sumres))
  
  # Add function inputs to obviate need to specify them in map()
  reslist <- append(x = reslist, values = list(
    covariate.names = covariate.names,
    samples = samples,
    prediction.grid = prediction.grid,
    coordinate.system = coordinate.system))
  
  reslist <- append(list(type = c("extrapolation", "mic")), reslist)
  
  # Keep it classy
  class(reslist) <- c("extrapolation_results", class(reslist))
  
  if(verbose) message("Done!")
  return(reslist)
  
}
